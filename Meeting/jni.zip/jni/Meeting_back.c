#include "Meeting.h"
#include "webrtcConf.h"

#include <stdio.h>
#include <pthread.h>
#include <android/log.h>

int conference;
MMixer gMix;

FILE *file[MAX_PARTICIPANT];
int delay[MAX_PARTICIPANT];
int loss[MAX_PARTICIPANT];
int tick[MAX_PARTICIPANT];
pthread_t thread[MAX_PARTICIPANT];

#ifndef __AND_LOG_TAG
#define __AND_LOG_TAG "audioProcess"
#endif

#define __AND_LOGD(...) __android_log_print(ANDROID_LOG_DEBUG  , __AND_LOG_TAG, __VA_ARGS__)
#define __AND_LOGI(...) __android_log_print(ANDROID_LOG_INFO   , __AND_LOG_TAG, __VA_ARGS__)
#define __AND_LOGW(...) __android_log_print(ANDROID_LOG_WARN   , __AND_LOG_TAG, __VA_ARGS__)
#define __AND_LOGE(...) __android_log_print(ANDROID_LOG_ERROR  , __AND_LOG_TAG, __VA_ARGS__)

void* readData(void *arg);
void initAudio(PMParticipant p,int id);
void thread_exit_handler(int sig);

JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_createConference
(JNIEnv * env, jclass cl)
{
    conference = 1;

    memset(&gMix,0,sizeof(MMixer));
    int i = 0;
    for(i = 0; i < MAX_PARTICIPANT; i++)
    {
        char a[30];
        sprintf(a,"/mnt/sdcard/record%d.pcm",i);
        file[i] = fopen(a,"rb");
        __AND_LOGD("the file name is %s, the file_open flag is %d\n",a,file[i]);
    }
    pthread_t threadTemp;
    initAudio(&gMix.participants[0],0);

    pthread_create(&threadTemp,NULL,readData,&gMix.participants[0]);
    thread[0] = threadTemp;
    __AND_LOGD("Thread[0] = %d\n",thread[0]);

}


JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_joinConference
(JNIEnv *env, jclass cl, jint number)
{
    pthread_t threadTemp;
    MParticipant part = gMix.participants[number];
    part.id = number;
    initAudio(&gMix.participants[number],number);

    pthread_create(&threadTemp,NULL,readData,&gMix.participants[number]);
    thread[number] = threadTemp;
    __AND_LOGD("join conference thread[number] = %d,participants id is %d\n",threadTemp,part.id);
}

JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_dropConference
(JNIEnv *env, jclass  cl, jint  number)
{
    if(thread[number] > 0)
    {
        __AND_LOGD("Before pthread_kill\n");
        int temp = pthread_kill(thread[number], SIGUSR2);
        if(temp != 0)
            __AND_LOGD("pthread_kill failed!\n");
    }
    __AND_LOGD("drop conference the thread id is %d\n",thread[number]);
    thread[number] = -1;
}

JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_networkDelay
(JNIEnv *env, jclass cl, jint number)
{
    delay[number] = 1;
}


JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_newtworkLoss
(JNIEnv *env, jclass cl, jint number)
{
    loss[number] = 1;
}

JNIEXPORT jbyteArray JNICALL Java_com_example_meeting_Meeting_getData
(JNIEnv *env, jclass cl)
{
    unsigned char data[320];
    jbyteArray ret = (*env)->NewByteArray(env,320);
    if((gMix.rIdx + 1) % MIXER_BUF_SIZE != gMix.wIdx)
    {
        int i;
        for(i = 0 ; i < 320; i++)
        {
            data[i] = gMix.oframes[gMix.rIdx++].buf[i];
        }
        (*env)->SetByteArrayRegion(env,ret,0,320,data);
    }
    return ret;
}

JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_conferenceOver
(JNIEnv *env, jclass cl)
{
    int i = 0;
    for(i = 0; i < MAX_PARTICIPANT; i++)
    {
        int threadFlag = pthread_kill(thread[i], SIGUSR2);
        if(threadFlag != 0)
            __AND_LOGD("thread id = %d,pthread_kill flag %d",i,threadFlag);
        thread[i] = -1;
    }

}

void* readData(void *arg)
{
    PMParticipant part = ( PMParticipant )arg;
    __AND_LOGD("readData id is %d\n",part->id);

    struct sigaction actions;
    memset(&actions, 0, sizeof(actions));
    sigemptyset(&actions.sa_mask);
    actions.sa_flags = 0;
    actions.sa_handler = thread_exit_handler;
    sigaction(SIGUSR2,&actions,NULL);

    while( 1 )
    {
        if((part->wIdx + 1) % PART_BUF_SIZE != part->rIdx)
        {

            if(delay[part->id]) goto end;
            unsigned char *p = part->iframes[(part->wIdx+1) % PART_BUF_SIZE].buf;
            part->iframes[(part->wIdx+1) % PART_BUF_SIZE].rwflag = FS_WRITEABLE;
            part->iframes[(part->wIdx+1) % PART_BUF_SIZE].tick = tick[part->id]++;
            int flag =0;
            __AND_LOGD("before fread %d\n",flag);
            flag = fread(p, sizeof(int16_t), 160, file[part->id]);
            __AND_LOGD("after fread %d\n",flag);
            part->tick = tick[part->id];
            part->wIdx = (part->wIdx+1) % PART_BUF_SIZE;

        }
end:
        sleep(18);
    }
}

void initAudio(PMParticipant p,int id)
{
    memset(p,0,sizeof(MParticipant));
    p->sample = 8000;
    p->id = id;
}

int haveAudio(PMParticipant p)
{
    return p->wIdx != p->rIdx;

}

int getAudio(PMParticipant p, MAudioFrame* data)
{
    if(p->rIdx != p->wIdx)
    {
        *data = p->iframes[p->rIdx];
        return 1;
    }
    else
        return 0;
}

void mixAudio()
{

    MAudioFrame audio[MAX_PARTICIPANT];
    memset(audio,0,sizeof(audio));

    int i;
    int partNum = 0;
    for(i = 0; i < MAX_PARTICIPANT; i++)
    {
        MParticipant p = gMix.participants[i];
        int flag = getAudio(&p, audio+partNum);
        partNum += flag;
    }

    mixAudio(audio, partNum);
}

void thread_exit_handler(int sig)
{
    __AND_LOGD("this signal is %d \n", sig);
    pthread_exit(0);
}
