#include "webrtcLog.h"

#include "webrtcWraper.h"
extern "C" void init_neteq()
{
}

extern "C" void neteq_process(unsigned char* in, unsigned char* out)
{
}

extern "C" void uinit_neteq()
{
}
