#include "Meeting.h"
#include "webrtcConf.h"
#include "webrtcConf.h"

#include <stdio.h>
#include <pthread.h>
#include <android/log.h>

int conference;
MMixerHandle gMix;

FILE *file[MAX_PARTICIPANT];
int delay[MAX_PARTICIPANT];
int loss[MAX_PARTICIPANT];
int tick[MAX_PARTICIPANT];
pthread_t thread[MAX_PARTICIPANT];
MPartiHandle participant[MAX_PARTICIPANT];


#ifndef __AND_LOG_TAG
#define __AND_LOG_TAG "audioProcess"
#endif

#define __AND_LOGD(...) __android_log_print(ANDROID_LOG_DEBUG  , __AND_LOG_TAG, __VA_ARGS__)
#define __AND_LOGI(...) __android_log_print(ANDROID_LOG_INFO   , __AND_LOG_TAG, __VA_ARGS__)
#define __AND_LOGW(...) __android_log_print(ANDROID_LOG_WARN   , __AND_LOG_TAG, __VA_ARGS__)
#define __AND_LOGE(...) __android_log_print(ANDROID_LOG_ERROR  , __AND_LOG_TAG, __VA_ARGS__)

void* readData(void *arg);
void initAudio(PMParticipant p,int id);
void thread_exit_handler(int sig);


JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_createConference
(JNIEnv * env, jclass cl)
{
    int i = 0;
    for(i = 0; i < MAX_PARTICIPANT; i++)
    {
        char a[30];
        sprintf(a,"/mnt/sdcard/record%d.pcm",i);
        file[i] = fopen(a,"rb");
        __AND_LOGD("the file name is %s, the file_open flag is %d\n",a,file[i]);
    }
    gMix = NewMixer(MAX_PARTICIPANT);

}


JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_joinConference
(JNIEnv *env, jclass cl, jint number)
{
    participant[number] = NewParticipant(gMix);
    pthread_create(&thread[number],NULL,readData,participant[number]);
}

JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_dropConference
(JNIEnv *env, jclass  cl, jint  number)
{
    DelParticipant(gMix,participant[number]);
}

JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_networkDelay
(JNIEnv *env, jclass cl, jint number)
{
    delay[number] = 1;
}


JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_newtworkLoss
(JNIEnv *env, jclass cl, jint number)
{
    loss[number] = 1;
}

JNIEXPORT jbyteArray JNICALL Java_com_example_meeting_Meeting_getData
(JNIEnv *env, jclass cl)
{
    unsigned char data[320];
    MAudioFrame* handle;

    handle = GetMixedFrame(gMix);
    jbyteArray ret = (*env)->NewByteArray(env,320);

	int i;
    for(i = 0 ; i < 320; i++)
    {
        data[i] = handle->buf[i];
    }
    (*env)->SetByteArrayRegion(env,ret,0,320,data);
	
    RecycleMixedFrame(gMix,handle);
	
    return ret;
}

JNIEXPORT void JNICALL Java_com_example_meeting_Meeting_conferenceOver
(JNIEnv *env, jclass cl)
{
    DelMixer(gMix);

}

void* readData(void *arg)
{
    MPartiHandle part = ( MPartiHandle )arg;
    __AND_LOGD("readData id is %d\n",part->id);
    MAudioFrame* data;


    struct sigaction actions;
    memset(&actions, 0, sizeof(actions));
    sigemptyset(&actions.sa_mask);
    actions.sa_flags = 0;
    actions.sa_handler = thread_exit_handler;
    sigaction(SIGUSR2,&actions,NULL);

    while( 1 )
    {
        data = ApplyPartiFrame( part );
        int i = 0;
        for(i = 0; i < MAX_PARTICIPANT; i++)
            if(participant[i] == part)
                break;
        fread(data->buf,2,160,file[i]);
        PushPartiFrame(part, data);
end:
        sleep(18);
    }
}

void initAudio(PMParticipant p,int id)
{
    memset(p,0,sizeof(MParticipant));
    p->sample = 8000;
    p->id = id;
}

int haveAudio(PMParticipant p)
{
    return p->wIdx != p->rIdx;

}

int getAudio(PMParticipant p, MAudioFrame* data)
{
    if(p->rIdx != p->wIdx)
    {
        *data = p->iframes[p->rIdx];
        return 1;
    }
    else
        return 0;
}


void thread_exit_handler(int sig)
{
    __AND_LOGD("this signal is %d \n", sig);
    pthread_exit(0);
}
